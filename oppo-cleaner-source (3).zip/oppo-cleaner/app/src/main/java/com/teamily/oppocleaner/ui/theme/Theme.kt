package com.teamily.oppocleaner.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF22D3EE)
val CyanDark = Color(0xFF0E7490)
val Bg = Color(0xFF0B1220)
val Surface1 = Color(0xFF141E2E)
val Surface2 = Color(0xFF1C2940)
val Danger = Color(0xFFF87171)
val Warn = Color(0xFFFBBF24)
val Good = Color(0xFF34D399)
val TextMain = Color(0xFFE8EEF7)
val TextDim = Color(0xFF93A4BC)

private val scheme = darkColorScheme(
    primary = Cyan,
    onPrimary = Color(0xFF04222B),
    primaryContainer = CyanDark,
    onPrimaryContainer = Color(0xFFD6F7FF),
    secondary = Color(0xFF7DD3FC),
    background = Bg,
    onBackground = TextMain,
    surface = Surface1,
    onSurface = TextMain,
    surfaceVariant = Surface2,
    onSurfaceVariant = TextDim,
    error = Danger,
    onError = Color(0xFF2A0A0A)
)

@Composable
fun OppoCleanerTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
