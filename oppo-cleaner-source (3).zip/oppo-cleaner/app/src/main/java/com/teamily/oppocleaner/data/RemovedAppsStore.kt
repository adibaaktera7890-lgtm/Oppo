package com.teamily.oppocleaner.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persists the list of apps this tool removed, so they can be restored later. */
class RemovedAppsStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("removed_apps", Context.MODE_PRIVATE)

    fun load(): List<RemovedApp> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            (0 until array.length()).mapNotNull { i ->
                val obj = array.optJSONObject(i) ?: return@mapNotNull null
                val pkg = obj.optString("packageName")
                if (pkg.isEmpty()) return@mapNotNull null
                RemovedApp(
                    packageName = pkg,
                    label = obj.optString("label", pkg),
                    action = if (obj.optString("action") == "DISABLE") RemovalAction.DISABLE else RemovalAction.UNINSTALL,
                    timestamp = obj.optLong("timestamp", 0L)
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun save(items: List<RemovedApp>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(
                JSONObject().apply {
                    put("packageName", item.packageName)
                    put("label", item.label)
                    put("action", item.action.name)
                    put("timestamp", item.timestamp)
                }
            )
        }
        prefs.edit().putString(KEY, array.toString()).apply()
    }

    fun add(item: RemovedApp): List<RemovedApp> {
        val current = load().filterNot { it.packageName == item.packageName }
        val updated = listOf(item) + current
        save(updated)
        return updated
    }

    fun remove(packageName: String): List<RemovedApp> {
        val updated = load().filterNot { it.packageName == packageName }
        save(updated)
        return updated
    }

    private companion object {
        const val KEY = "items"
    }
}
