package com.teamily.oppocleaner

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.teamily.oppocleaner.data.JunkItem
import com.teamily.oppocleaner.data.JunkScanner
import com.teamily.oppocleaner.data.RemovalAction
import com.teamily.oppocleaner.data.RemovedApp
import com.teamily.oppocleaner.data.RemovedAppsStore
import com.teamily.oppocleaner.data.RootState
import com.teamily.oppocleaner.data.SystemApp
import com.teamily.oppocleaner.data.SystemAppRepository
import com.teamily.oppocleaner.root.RootShell
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val root: RootState = RootState.Checking,
    val junk: List<JunkItem> = emptyList(),
    val selectedJunk: Set<String> = emptySet(),
    val scanning: Boolean = false,
    val apps: List<SystemApp> = emptyList(),
    val loadingApps: Boolean = false,
    val appQuery: String = "",
    val systemOnly: Boolean = true,
    val removed: List<RemovedApp> = emptyList(),
    val busy: Boolean = false,
    val message: String? = null
)

class AppViewModel(app: Application) : AndroidViewModel(app) {

    private val store = RemovedAppsStore(app)
    private val _state = MutableStateFlow(UiState(removed = store.load()))
    val state: StateFlow<UiState> = _state.asStateFlow()

    init {
        checkRoot()
    }

    fun consumeMessage() {
        _state.update { it.copy(message = null) }
    }

    fun checkRoot() {
        viewModelScope.launch {
            _state.update { it.copy(root = RootState.Checking) }
            val granted = RootShell.hasRoot()
            if (granted) {
                val version = RootShell.kernelSuVersion()
                _state.update { it.copy(root = RootState.Granted(version)) }
            } else {
                _state.update {
                    it.copy(
                        root = RootState.Denied(
                            "su কমান্ড ব্যর্থ হয়েছে। KernelSU ম্যানেজারে এই অ্যাপকে root অনুমতি দিন, তারপর আবার চেষ্টা করুন।"
                        )
                    )
                }
            }
        }
    }

    fun scanJunk() {
        if (_state.value.root !is RootState.Granted) {
            _state.update { it.copy(message = "রুট পারমিশন ছাড়া স্ক্যান করা যাবে না।") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(scanning = true) }
            val items = JunkScanner.scan(getApplication<Application>())
            _state.update { current ->
                current.copy(
                    junk = items,
                    scanning = false,
                    selectedJunk = items.filter { it.sizeBytes > 0 && !it.target.risky }
                        .map { it.target.id }
                        .toSet()
                )
            }
        }
    }

    fun toggleJunk(id: String) {
        _state.update { current ->
            val next = if (id in current.selectedJunk) current.selectedJunk - id
            else current.selectedJunk + id
            current.copy(selectedJunk = next)
        }
    }

    fun selectAllJunk() {
        _state.update { current ->
            val all = current.junk.filter { it.sizeBytes > 0 }.map { it.target.id }.toSet()
            val next = if (current.selectedJunk.containsAll(all) && all.isNotEmpty()) emptySet() else all
            current.copy(selectedJunk = next)
        }
    }

    fun deleteSelectedJunk() {
        val current = _state.value
        val chosen = current.junk.filter { it.target.id in current.selectedJunk && it.sizeBytes > 0 }
        if (chosen.isEmpty()) {
            _state.update { it.copy(message = "ডিলিট করার জন্য কিছু নির্বাচন করা হয়নি।") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val (count, detail) = JunkScanner.delete(getApplication<Application>(), chosen)
            val freed = chosen.sumOf { it.sizeBytes }
            val refreshed = JunkScanner.scan(getApplication<Application>())
            _state.update {
                it.copy(
                    busy = false,
                    junk = refreshed,
                    selectedJunk = emptySet(),
                    message = if (count > 0)
                        "${chosen.size}টি ক্যাটাগরি পরিষ্কার হয়েছে (প্রায় ${formatBytes(freed)} খালি হয়েছে)।"
                    else
                        "ডিলিট ব্যর্থ: ${detail.take(160)}"
                )
            }
        }
    }

    fun loadApps() {
        if (_state.value.root !is RootState.Granted) {
            _state.update { it.copy(message = "রুট পারমিশন ছাড়া অ্যাপ লিস্ট দেখা যাবে না।") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(loadingApps = true) }
            val apps = SystemAppRepository.loadApps(getApplication<Application>(), _state.value.systemOnly)
            _state.update {
                it.copy(
                    apps = apps,
                    loadingApps = false,
                    message = if (apps.isEmpty()) "কোনো অ্যাপ পাওয়া যায়নি।" else null
                )
            }
        }
    }

    fun setAppQuery(query: String) {
        _state.update { it.copy(appQuery = query) }
    }

    fun setSystemOnly(systemOnly: Boolean) {
        _state.update { it.copy(systemOnly = systemOnly) }
        loadApps()
    }

    fun removeApp(app: SystemApp, action: RemovalAction) {
        if (app.protected) {
            _state.update { it.copy(message = "${app.label} সুরক্ষিত — এই অ্যাপ মোছা যাবে না।") }
            return
        }
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val (success, detail) = when (action) {
                RemovalAction.UNINSTALL -> SystemAppRepository.uninstall(app.packageName)
                RemovalAction.DISABLE -> SystemAppRepository.disable(app.packageName)
            }
            if (success) {
                val updated = store.add(
                    RemovedApp(
                        packageName = app.packageName,
                        label = app.label,
                        action = action,
                        timestamp = System.currentTimeMillis()
                    )
                )
                _state.update {
                    it.copy(
                        busy = false,
                        removed = updated,
                        apps = it.apps.filterNot { a -> a.packageName == app.packageName },
                        message = "${app.label} ${if (action == RemovalAction.UNINSTALL) "আনইনস্টল" else "ডিজেবল"} হয়েছে।"
                    )
                }
            } else {
                _state.update {
                    it.copy(busy = false, message = "ব্যর্থ: ${detail.take(180)}")
                }
            }
        }
    }

    fun restoreApp(item: RemovedApp) {
        viewModelScope.launch {
            _state.update { it.copy(busy = true) }
            val (success, detail) = when (item.action) {
                RemovalAction.UNINSTALL -> SystemAppRepository.restore(item.packageName)
                RemovalAction.DISABLE -> SystemAppRepository.enable(item.packageName)
            }
            if (success) {
                val updated = store.remove(item.packageName)
                _state.update {
                    it.copy(
                        busy = false,
                        removed = updated,
                        message = "${item.label} ফিরিয়ে আনা হয়েছে।"
                    )
                }
                loadApps()
            } else {
                _state.update {
                    it.copy(busy = false, message = "ফিরিয়ে আনা ব্যর্থ: ${detail.take(180)}")
                }
            }
        }
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var index = 0
    while (value >= 1024.0 && index < units.size - 1) {
        value /= 1024.0
        index++
    }
    return if (index == 0) "$bytes B"
    else String.format(java.util.Locale.US, "%.1f %s", value, units[index])
}
