package com.teamily.oppocleaner.root

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/** Result of one shell command run through `su`. */
data class ShellResult(
    val exitCode: Int,
    val stdout: String,
    val stderr: String
) {
    val ok: Boolean get() = exitCode == 0
    val combined: String get() = (stdout + "\n" + stderr).trim()
}

/**
 * Runs commands as root through KernelSU's `su`.
 *
 * Multi-line scripts are written to a file in the app cache and executed with
 * `sh <file>`, so no shell quoting has to survive the Kotlin string layer.
 */
object RootShell {

    suspend fun run(command: String, timeoutSeconds: Long = 60): ShellResult =
        exec(listOf("su", "-c", command), timeoutSeconds)

    /** Writes [script] to a temp file and runs it as root. */
    suspend fun runScript(
        context: Context,
        script: String,
        timeoutSeconds: Long = 120
    ): ShellResult = withContext(Dispatchers.IO) {
        val dir = File(context.cacheDir, "rootjobs").apply { mkdirs() }
        val file = File(dir, "job_${System.nanoTime()}.sh")
        try {
            file.writeText(script)
            exec(listOf("su", "-c", "sh '${file.absolutePath}'"), timeoutSeconds)
        } catch (e: Exception) {
            ShellResult(-1, "", e.message ?: "could not write script")
        } finally {
            try { file.delete() } catch (_: Exception) { }
        }
    }

    private suspend fun exec(argv: List<String>, timeoutSeconds: Long): ShellResult =
        withContext(Dispatchers.IO) {
            var process: Process? = null
            try {
                val started = ProcessBuilder(argv).start()
                process = started
                val out = StringBuilder()
                val err = StringBuilder()

                val outReader = Thread {
                    BufferedReader(InputStreamReader(started.inputStream)).use { r ->
                        out.append(r.readText())
                    }
                }
                val errReader = Thread {
                    BufferedReader(InputStreamReader(started.errorStream)).use { r ->
                        err.append(r.readText())
                    }
                }
                outReader.start()
                errReader.start()

                val finished = started.waitFor(timeoutSeconds, TimeUnit.SECONDS)
                if (!finished) {
                    started.destroy()
                    return@withContext ShellResult(-1, out.toString(), "timeout after ${timeoutSeconds}s")
                }
                outReader.join(2000)
                errReader.join(2000)
                ShellResult(started.exitValue(), out.toString(), err.toString())
            } catch (e: Exception) {
                ShellResult(-1, "", e.message ?: "su is not available")
            } finally {
                try { process?.destroy() } catch (_: Exception) { }
            }
        }

    /** True when `su -c id` reports uid=0. */
    suspend fun hasRoot(): Boolean {
        val result = run("id", timeoutSeconds = 20)
        return result.ok && result.stdout.contains("uid=0")
    }

    /** KernelSU version string, when available. */
    suspend fun kernelSuVersion(): String? {
        val result = run("su -v", timeoutSeconds = 15)
        val text = result.stdout.trim()
        return if (result.ok && text.isNotEmpty()) text else null
    }
}