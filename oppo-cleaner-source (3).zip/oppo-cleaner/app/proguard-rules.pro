# Keep default rules. No custom shrinking rules needed.
